module.exports = {
    host: "localhost",
    user: "root",
    password: "root",
    database: "nodejs"
}

